package foxandthehounds.game_logic;

public class Fox extends Figure {
    public Fox(int row, int col) {
        super(row, col);

    }
}

