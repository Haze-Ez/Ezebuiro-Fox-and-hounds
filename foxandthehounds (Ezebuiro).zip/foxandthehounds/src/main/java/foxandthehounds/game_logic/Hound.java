package foxandthehounds.game_logic;

public class Hound extends Figure {
    public Hound(int row, int col) {
        super(row, col);
    }
}
